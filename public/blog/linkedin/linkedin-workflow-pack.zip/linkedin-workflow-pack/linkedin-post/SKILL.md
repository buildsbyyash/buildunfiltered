---
name: linkedin-post
description: Writes a LinkedIn post about what I worked on or learned, in my own voice. Use when I ask for a LinkedIn post, or when the daily LinkedIn scheduled task runs.
---

# My LinkedIn post skill

## Who I am
- Role: [e.g. developer learning AI]
- I post about: [e.g. what I learn and build in AI: context engineering, agents, tools]
- My readers: [e.g. recruiters, developers, founders]

## Where today's material comes from
1. My recent Claude chats and the files in my Project: [Project name]
2. Or my running notes doc: [link or file name]
Use only things I actually did or learned. Never invent projects, numbers, clients or results. If there's nothing new today, write: "Nothing new to post today" and stop.

## My voice
<!-- Fill this in from your first post (step 2C). Examples of the kind of rules that go here: -->
- First line: [e.g. a blunt claim or a mistake I made, under 12 words]
- Length: [e.g. 80–150 words]
- Sentences: [e.g. short, plain words, first person, like I'm talking to a friend]
- Layout: [e.g. one sentence per line, a blank line between ideas]
- Example: [e.g. always one real example from my day]
- Ending: [e.g. one question people can answer in the comments]
- Hashtags: [e.g. 0–3 at the end]
- Emojis: [e.g. none, or max 1]

## Never do
<!-- Every correction you made in step 2 goes here as a rule. -->
- No "thrilled to announce", "excited to share", "humbled", "game-changer", "in today's fast-paced world".
- No made-up stats or results.
- No more than one idea per post.
- [your corrections]

## Style reference (optional)
Structure borrowed from a creator I like (structure only, never their words):
- [e.g. opens with a short failure story]
- [e.g. 3 short lines, then the lesson]

## Example post (the one I approved)
```
[paste your final first post here]
```

## Output
Return only the post text, ready to paste into LinkedIn. No title, no notes, no quotation marks.
