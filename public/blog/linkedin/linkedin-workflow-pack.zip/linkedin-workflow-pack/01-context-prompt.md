# Step 1: Context prompt

Paste this into Claude, ideally inside the Project where your work lives. Fill in the [brackets]. Attach your notes or docs, or paste links.

---

```
I want to post on LinkedIn regularly about what I'm learning and building. Before you write anything, get to know my work.

Who I am: [your role, e.g. "final-year CS student" / "product manager learning AI" / "backend developer"]
What I'm working on right now: [projects, a course, a side project, work tasks]
What I'm learning: [topics, e.g. "context engineering, AI agents, MCP"]
Who I want to reach on LinkedIn: [e.g. "recruiters for AI roles", "founders", "other developers"]

My references (read these): [attach notes / docs, or paste links]

Do this:
1. Read everything above and in this Project.
2. Give me a list of 10 post ideas from MY actual work. Each one is a single line: what I did or learned, and why someone else would care.
3. Mark the 3 strongest ideas and tell me why.

Don't write any posts yet. Don't make up projects, numbers or results that aren't in my material. If something is missing, ask me.
```

---

**Tip:** if you don't work inside Claude, keep one running doc called "What I did this week" and drop 2–3 lines into it each day. Point the scheduled task at that doc in Step 3.
