# Step 2: Your first post, by hand

This is the most important step. You teach Claude your voice once, and every post after that uses it.

## A. Write the first post together

Paste this into the same chat as Step 1:

```
Pick the strongest idea from your list and write my first LinkedIn post about it.

Rules for now:
- Write like a real person talking, not a press release. No "thrilled to announce", "excited to share" or "humbled".
- Open with one line that makes people stop scrolling: a blunt claim, a mistake I made, or a surprising result.
- One idea per post. A real example from my work.
- Short lines, with white space between them.
- Under 150 words.
- End with a question people can answer in the comments.
- 0–3 hashtags at the end, or none.

Give me 2 versions with different openings.
```

Then keep changing it until **you** would post it. Quick feedback that works:
- "Less corporate."
- "Shorter. Cut anything I wouldn't say out loud."
- "This line doesn't sound like me. I'd say it like: ___"
- "Make the first line stronger."
- "Use my real example: ___"

## B. Optional: borrow a creator's style

```
Here are 3 LinkedIn posts from a creator whose style I like:

[paste post 1]
[paste post 2]
[paste post 3]

Don't copy their words or topics. Work out their STRUCTURE: how they open, line length, how they use white space, how they move to the point, how they end. List it in 5–7 bullet points. Then rewrite my post using that structure, in my own words, about my own work.
```

## C. Lock the style into a skill

Once you have a post you love:

```
I'm happy with this post. Now fill in the attached SKILL.md template from everything I approved and corrected in this conversation.
- Under "My voice", write the rules I actually followed, with an example of each.
- Under "Never do", list every change I asked you to make, as rules.
- Paste my final post under "Example post".
Keep the frontmatter (name and description) as it is. Return the full file.
```

Attach `linkedin-post/SKILL.md` to that message. Save what Claude gives back as `linkedin-post/SKILL.md`, zip the `linkedin-post` folder, and add it in Claude: Customize → Skills → + → Upload a skill.
