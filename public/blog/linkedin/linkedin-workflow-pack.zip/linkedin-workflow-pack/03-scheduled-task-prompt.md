# Step 3: The scheduled task

## Set it up
1. Install **Claude in Chrome** and log in to LinkedIn in that Chrome (log in yourself, never put your password in a prompt).
2. In Claude, open **Scheduled** and create a new task.
   - **Name:** Daily LinkedIn post
   - **Frequency:** Daily (or whatever you want, e.g. Mon/Wed/Fri)
   - **Time:** e.g. 9:00 AM
3. Paste the instructions below.
4. **Test it first:** set it to run 5 minutes from now and watch. Check the draft is saved, and whether the task ran with your laptop closed.

## Instructions (paste this)

```
Use my linkedin-post skill.

1. Look at what I worked on or learned since the last post: my recent Claude chats, the files in my [Project name] Project, and [my notes doc / link].
2. Pick the ONE most interesting thing. If there's nothing new, stop and tell me "Nothing new to post today". Don't post filler.
3. Write the post with my linkedin-post skill. Follow it exactly.
4. Open linkedin.com in Chrome. I'm already logged in.
5. Click "Start a post" and type the post into the box.
6. DO NOT click "Post". Close the post box with the X and choose "Save as draft" when LinkedIn asks.
7. Tell me: the post text, and that it's saved as a draft.

Rules:
- Never click Post, Publish or Schedule on LinkedIn. I always publish myself.
- Don't like, comment, connect, message or click anything else on LinkedIn.
- If LinkedIn asks me to log in, shows a captcha, or anything looks different, stop and tell me. Don't try to get around it.
```

## Every day (about 1 minute)
1. Open LinkedIn → Start a post → open your **drafts**.
2. Read it. Change anything that doesn't sound like you.
3. Press **Post**.
4. If you changed something, add that change to `SKILL.md` under "Never do" or "My voice". The drafts get better every week.

## Why it stops at the draft
LinkedIn's User Agreement (section 8.2) says you may not use "bots or other unauthorized automated methods" to create posts. Claude does the writing. The last click is yours, and your account stays safe.
