# LinkedIn posts with Claude: the full setup

Claude writes a LinkedIn post about what you did that day, in your voice, and saves it as a **draft**. You read it and press Post.

Setup takes about 30 minutes, once. After that it's about 1 minute a day.

## What's in this pack

| File | What it's for | When |
|---|---|---|
| `01-context-prompt.md` | Tells Claude what you're working on and learning | Step 1, once (and whenever your work changes) |
| `02-first-post-prompt.md` | Makes your first post with Claude until it sounds like you | Step 2, once |
| `linkedin-post/SKILL.md` | Your writing style saved as a skill, so every post sounds the same | Step 2, fill it in once |
| `03-scheduled-task-prompt.md` | The daily task: write the post, open LinkedIn, save the draft | Step 3, once |

## The 3 steps

### Step 1: Give Claude your context
- **If you already work in Claude** (chats, Projects, files), it already has your context. Put your work in one Project so it's all in one place.
- **If you don't,** give it a reference: your notes, a doc, a link, a GitHub repo, or a short "what I did today" note.

Then paste `01-context-prompt.md`.

### Step 2: Make your first post by hand, then turn it into a skill
1. Paste `02-first-post-prompt.md` and work with Claude. Keep asking for changes ("less corporate", "shorter", "sound like me") until **you** would post it.
2. Optional: paste 2–3 posts from a creator whose style you like. Claude copies the structure (hook, line breaks, ending), not their words.
3. When you like it, ask Claude to fill in `linkedin-post/SKILL.md` from that conversation. Then add the skill to Claude: Customize → Skills → + → Upload a skill, and upload the `linkedin-post` folder as a zip.

### Step 3: Schedule it, with Claude using your browser
LinkedIn has no official Claude connector, so Claude uses your browser like you would.
1. Install **Claude in Chrome** and log in to LinkedIn in that Chrome.
2. Create a scheduled task in Claude (the Scheduled section), daily or however often you want. Paste `03-scheduled-task-prompt.md` as the instructions.
3. Each day Claude writes the post with your skill, opens LinkedIn, types it in and **saves it as a draft**.
4. **You** open LinkedIn, read the draft, edit it if needed, and press Post.

## Why you press Post yourself
LinkedIn's User Agreement (section 8.2) says you may not use "bots or other unauthorized automated methods" to create posts. If Claude saves a draft, the last click is yours. That keeps your account safe, and you read every post before it goes out.

## Before you rely on it
- **Check whether your computer needs to stay on.** Depending on your Claude plan and app, a scheduled task may run in the cloud, or only while the desktop app is open. Test it once: schedule a run 5 minutes ahead and watch what happens.
- **The first week, read every draft carefully.** Each time you fix something, add the fix to `SKILL.md` so you don't have to fix it again.
- **Never give Claude your LinkedIn password in a prompt.** Log in to Chrome yourself.
